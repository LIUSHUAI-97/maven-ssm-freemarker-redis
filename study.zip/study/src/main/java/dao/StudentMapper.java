package dao;

import entity.StudentEntity;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface StudentMapper {

    @Insert("insert into student(stu_no,stu_name,stu_address,birth) values(#{stuNo}," +
            "#{stuName},#{stuAddress},#{birth})")
    public int addStu(StudentEntity studentEntity);

    @Select("select * from student")
    @Results(value = {@Result(column = "stu_id", property = "stuId"),
            @Result(column = "stu_no", property = "stuNo"),
            @Result(column = "stu_name", property = "stuName"), @Result(column = "stu_address", property = "stuAddress"),
            @Result(column = "birth", property = "birth")})
    public List<StudentEntity> findAll();

    @Select("select * from student where stu_name=#{stuName}")
    @Results(value = {@Result(column = "stu_id", property = "stuId"),
            @Result(column = "stu_no", property = "stuNo"),
            @Result(column = "stu_name", property = "stuName"), @Result(column = "stu_address", property = "stuAddress"),
            @Result(column = "birth", property = "birth")})
    public StudentEntity searchOne(String stuName);

    @Select("select * from student where stu_no=#{stuNo}")
    @Results(value = {@Result(column = "stu_id", property = "stuId"),
            @Result(column = "stu_no", property = "stuNo"),
            @Result(column = "stu_name", property = "stuName"), @Result(column = "stu_address", property = "stuAddress"),
            @Result(column = "birth", property = "birth")})
    public StudentEntity findOneByStuNo(int stuNo);

    @Delete("delete from student where stu_no= #{stuNo}")
    public int delete(int stuNo);

    @Update("update student set stu_name=#{stuName},stu_address=#{stuAddress},birth=#{birth} where stu_no=#{stuNo}")
    public int modify(StudentEntity studentEntity);
}
