package util;

import redis.clients.jedis.Jedis;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

public class RedisUtils {

    private static String hostname;
    private static int port;
    private static String password;

    /*
    *  properties：获取redis.properties配置文件中所有redis属性配置
    *  hostname：redis的主机ip地址
    *  port：redis的端口号
    *  password：redis的密码
    *
    * */
    static {
        Properties properties = PropertiesManager.getInstance().loadProperties("redis.properties");
        hostname = properties.getProperty("redis.hostname", "127.0.0.1");
        port = Integer.valueOf(properties.getProperty("redis.port", "6379"));
        password = properties.getProperty("redis.password", "");
    }

    /* 判断redis服务是否存活  */
    public static boolean getRedisServiceIsAlive() {
        boolean isAlive = false;
        try {
            Jedis jedis = new Jedis(hostname, port);
            String pong = jedis.ping();
            if ("PONG".equals(pong)) {
                isAlive = true;
            }
        } catch (Exception e) {
            isAlive = false;
            System.out.println("Redis 服务已经死掉了");
        } finally {
            return isAlive;
        }
    }

    /*  将存在redis中的map对象转化成list对象  */
    public static <T> List<T> getCollectionObjectList(Collection<Object> collection, Class T) {
        List<T> list = new ArrayList<T>(collection.size());
        for (Object obj : collection) {
            T target = (T) obj;
            list.add(target);
        }
        return list;
    }
}
