package util;

import java.io.*;
import java.net.URISyntaxException;
import java.util.Properties;

public class PropertiesManager {

    //声明一个单例，volatile保证线程的可见性（可以不要）
    private static volatile PropertiesManager instance;

    // 声明一个辅助对象，用于synchronized加锁用
    static Object object = new Object();

    private PropertiesManager() {
        // 私有构造方法，防止被其他类new
    }

    /*获取实例对象*/
    public static PropertiesManager getInstance() {
        // 判断单例对象instance是否存在，存在，则直接返回已存在的instance
        if (null == instance) {
            synchronized (object){
                if (null == instance) {
                    // 不存在，则创建instance单例再返回
                    instance = new PropertiesManager();
                }
            }
        }
        // 最后返回
        return instance;
    }


    /*读取 **.properties 配置文件中属性，传入的参数表示读取哪个配置文件*/
    public Properties loadProperties(String propertiesName) {
        Properties properties = new Properties();
        try {
            InputStream in = new FileInputStream(new File(PropertiesManager.class.getResource(
                    "/properties/" + propertiesName).toURI()));
            properties.load(in);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return properties;
    }
}
