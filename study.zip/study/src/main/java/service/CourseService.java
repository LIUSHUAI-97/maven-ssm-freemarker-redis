package service;

import entity.CourseEntity;

import java.util.List;

public interface CourseService {

    public CourseEntity searchOne(int courseNo);

    public boolean addOne(CourseEntity courseEntity);

    public boolean deleteOne(int courseNo);

    public boolean modify(CourseEntity courseEntity);
}
