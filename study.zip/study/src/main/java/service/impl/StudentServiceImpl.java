package service.impl;

import dao.StudentMapper;
import entity.StudentEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import service.StudentService;
import util.RedisUtils;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentMapper studentMapper;

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public static final String STUDENT_MAP_KEY = "studentMap";

    /**
     * 根据学号查询学生信息
     *
     * @param stuNo
     * @return
     */
    @Override
    public StudentEntity findOneByStuNo(int stuNo) {
        /**
         * 0.判断redis是否存活，如果死了，直接操作数据库，如果存活，则操作redis
         * 1.先从redis中读取学生信息
         * 如果从redis中读取的不为null,则直接返回学生信息
         * 如果redis中读取的为null，
         * 则去数据库中查询，并且将查询出的结果添加到redis中，
         * 最后返回学生信息。
         */
        StudentEntity studentEntity = null;
        if (RedisUtils.getRedisServiceIsAlive()) {   //redis存活
            // 先从redis中get()学生信息，
            studentEntity = (StudentEntity) redisTemplate.opsForHash().get(STUDENT_MAP_KEY, stuNo);
            if (null == studentEntity) {

                // 如果redis中读取不到，就从数据库中查询
                studentEntity = studentMapper.findOneByStuNo(stuNo);

                // 将查询的结果put()到redis中
                redisTemplate.opsForHash().put(STUDENT_MAP_KEY, stuNo, studentEntity);

            }
        } else {

            // redis死了，直接查数据库
            studentEntity = studentMapper.findOneByStuNo(stuNo);
        }

        // 返回学生对象信息
        return studentEntity;

//   不用redis的写法就一句话：     return studentMapper.findOneByStuNo(stuNo);
    }

    @Override
    public boolean deleteOne(int stuNo) {

        int stu = studentMapper.delete(stuNo);

        if (stu > 0) {
            /**
             * 删除数据库成功后，要delete()  redis中缓存信息
             */
            redisTemplate.opsForHash().delete(STUDENT_MAP_KEY, stuNo);
            return true;
        } else {
            return false;
        }

    }

    @Override
    public boolean addOne(StudentEntity studentEntity) {

        int success = studentMapper.addStu(studentEntity);

        if (success > 0) {
            /**
             * 添加到数据库后，同时将信息put() 到redis中
             */
            redisTemplate.opsForHash().put(STUDENT_MAP_KEY, studentEntity.getStuNo(), studentEntity);
            return true;
        } else {
            return false;
        }

    }

    @Override
    public boolean modify(StudentEntity studentEntity) {

        int success = studentMapper.modify(studentEntity);

        if (success > 0) {
            /**
             * 修改成功后，需要put()信息到缓存中
             */
            redisTemplate.opsForHash().put(STUDENT_MAP_KEY, studentEntity.getStuNo() + "", studentEntity);
            return true;

        } else {
            return false;
        }

    }
}
