package service.impl;

import dao.CourseMapper;
import entity.CourseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {
    @Autowired
    CourseMapper courseMapper;

    @Override
    public CourseEntity searchOne(int courseNo) {

        return courseMapper.selectOne(courseNo);
    }

    @Override
    public boolean addOne(CourseEntity courseEntity) {
        int success = courseMapper.addCourse(courseEntity);
        if(success>0){
            return true;
        }else{
            return false;
        }

    }

    @Override
    public boolean deleteOne(int courseNo) {
        int success = courseMapper.deleteOne(courseNo);
        if(success>0){
            return true;
        }else{
            return false;
        }

    }

    @Override
    public boolean modify(CourseEntity courseEntity) {

        int success = courseMapper.modify(courseEntity);
        if(success>0){
            return true;
        }else{
            return false;
        }

    }
}
