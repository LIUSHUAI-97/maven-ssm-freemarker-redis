package service;

import entity.StudentEntity;

public interface StudentService {
    public StudentEntity findOneByStuNo(int stuNo);

    public boolean deleteOne(int stuNo);

    public boolean addOne(StudentEntity studentEntity);

    public boolean modify(StudentEntity studentEntity);
}
