package dao;

import entity.CourseEntity;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface CourseMapper {

    @Insert("insert into course(course_no,course_name) values(#{courseNo},#{courseName})")
    public int addCourse(CourseEntity courseEntity);

    @Select("select * from course")
    @Results(value = {@Result(column = "course_id", property = "courseId"),
            @Result(column = "course_no", property = "courseNo"),
            @Result(column = "course_name", property = "courseName")})
    public List<CourseEntity> findAll();

    @Select("select * from course where course_no = #{courseNo}")
    @Results(value = {@Result(column = "course_id", property = "courseId"),
            @Result(column = "course_no", property = "courseNo"),
            @Result(column = "course_name", property = "courseName")})
    public CourseEntity selectOne(int courseNo);

    @Delete("delete from course where course_no = #{courseNo}")
    public int deleteOne(int courseNo);

    @Update("update course set course_name=#{courseName} where course_no=#{courseNo}")
    public int modify(CourseEntity courseEntity);
}
