package entity;

public class CourseEntity {

    private int courseId;

    private int courseNo;

    private String courseName;

    public CourseEntity() {
    }

    public CourseEntity(int courseId, int courseNo, String courseName) {
        this.courseId = courseId;
        this.courseNo = courseNo;
        this.courseName = courseName;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public int getCourseNo() {
        return courseNo;
    }

    public void setCourseNo(int courseNo) {
        this.courseNo = courseNo;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
