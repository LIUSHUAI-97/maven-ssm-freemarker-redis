package controller;

import entity.StudentEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import service.StudentService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/stu")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @RequestMapping(value = "/stuNo", method = RequestMethod.POST)
    public Map<String, Object> getStuInfoByStuId(@RequestBody Map<String, Object> param) {
        Map<String, Object> resMap = new HashMap<>();    // 定义一个存储返回结果的map

        // 获取param中参数
        int stuNo = Integer.valueOf((String) param.get("stuNo"));

        // 调用studentService中findOneByStuNo方法
        StudentEntity studentEntity = studentService.findOneByStuNo(stuNo);

        if (null != studentEntity) {
            resMap.put("success", true);
            resMap.put("data", studentEntity);
        } else {
            resMap.put("success", false);
            resMap.put("msg", "没有该学生");
        }

        return resMap;
    }

    @RequestMapping(value = "/del", method = RequestMethod.POST)
    public Map<String, Object> deleteOne(@RequestBody Map<String, Object> param) {
        Map<String, Object> resMap = new HashMap<>();

        int stuNo = Integer.valueOf((String) param.get("stuNo"));

        boolean success = studentService.deleteOne(stuNo);

        if (success) {
            resMap.put("success", true);
        } else {
            resMap.put("success", false);
        }
        return resMap;
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public Map<String, Object> addOne(@RequestBody Map<String, Object> param) throws ParseException {
        Map<String, Object> resMap = new HashMap<>();

        boolean success = false;

        try {
            int stuNo = Integer.valueOf((String) param.get("stuNo"));
            String stuName = (String) param.get("stuName");
            String stuAddress = (String) param.get("stuAddress");
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
            Date birth = sdf.parse((String) param.get("birth"));

            StudentEntity studentEntity = new StudentEntity();
            studentEntity.setStuNo(stuNo);
            studentEntity.setStuName(stuName);
            studentEntity.setStuAddress(stuAddress);
            studentEntity.setBirth(birth);

            success = studentService.addOne(studentEntity);
        } catch (Exception e) {
            resMap.put("success", false);
            resMap.put("msg", "添加失败！");
            return resMap;
        }

        if (success) {
            resMap.put("success", true);
        } else {
            resMap.put("success", false);
            resMap.put("msg", "添加失败！");
        }
        return resMap;
    }

    @RequestMapping(value = "/modify", method = RequestMethod.POST)
    public Map<String, Object> modify(@RequestBody Map<String, Object> param) throws ParseException {


        Map<String, Object> resMap = new HashMap<>();

        int stuNo = Integer.valueOf((String) param.get("stuNo"));
        String stuName = (String) param.get("stuName");
        String stuAddress = (String) param.get("stuAddress");
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        Date birth = sdf.parse((String) param.get("birth"));

        StudentEntity studentEntity = studentService.findOneByStuNo(stuNo);
        studentEntity.setStuNo(stuNo);
        studentEntity.setStuName(stuName);
        studentEntity.setStuAddress(stuAddress);
        studentEntity.setBirth(birth);

        boolean success = studentService.modify(studentEntity);

        if (success) {
            resMap.put("success", true);
            resMap.put("data", studentEntity);
        } else {
            resMap.put("success", false);
            resMap.put("msg", "修改失败！");
        }
        return resMap;
    }
}
