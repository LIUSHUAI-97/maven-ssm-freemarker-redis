package entity;

import java.util.Date;

public class GradeEntity {

    private int gradeId;

    private int stuNo;

    private int courseNo;

    private int grade;

    private Date checkTime;

    public GradeEntity() {
    }

    public GradeEntity(int gradeId, int stuNo, int courseNo, int grade, Date checkTime) {
        this.gradeId = gradeId;
        this.stuNo = stuNo;
        this.courseNo = courseNo;
        this.grade = grade;
        this.checkTime = checkTime;
    }

    public int getGradeId() {
        return gradeId;
    }

    public void setGradeId(int gradeId) {
        this.gradeId = gradeId;
    }

    public int getStuNo() {
        return stuNo;
    }

    public void setStuNo(int stuNo) {
        this.stuNo = stuNo;
    }

    public int getCourseNo() {
        return courseNo;
    }

    public void setCourseNo(int courseNo) {
        this.courseNo = courseNo;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public Date getCheckTime() {
        return checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }
}
