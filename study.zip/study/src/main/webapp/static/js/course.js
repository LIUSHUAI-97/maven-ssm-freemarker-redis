
function cancel(dialogId) {
    $("#" + dialogId).dialog('close');
}

/*
* 根据编号获取课程信息
* */
function getCourseInfoByNo(courseNo) {
    var course;

    var url = baseUrl+"/course/selectOne";
    var param = {};
    param.courseNo = courseNo + "";

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        async: false,   // 取消异步执行，按照代码顺序同步执行
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                course = result.data;
            }else{
                alert(result.msg);// 查询失败，则提示失败信息
            }
        }
    })
    return course;
}

function searchOne(courseNo) {
    console.log(courseNo);

    var course = getCourseInfoByNo(courseNo);
    console.log(course);

    $("#info-courseNo").textbox('setText',course.courseNo);
    $("#info-courseName").textbox('setText',course.courseName);

    $("#info-dialog").dialog('open');
}


function add() {
    $("#info-dialog-add").dialog('open');
}
function saveadd() {

    var courseNo = $("#info-courseNo-add").textbox("getText",courseNo);
    var courseName = $("#info-courseName-add").textbox("getText",courseName);

    var param={};
    param.courseNo = courseNo+"";
    param.courseName = courseName;

    url = baseUrl+"/course/add";

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                param = result.data;
                $.messager.alert("success","添加成功","info");
                window.location.reload();
            }else{
                $.messager.alert("error","添加失败","error");
            }
        }
    })
    $("#info-dialog-add").dialog('open')
}

function deleteOne(courseNo) {

    // var courseNo = $().textbox("getText");

    var param = {};

    param.courseNo = courseNo+"";

    url = baseUrl+"/course/del";

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                window.location.reload();
            }else{
                $.messager.alert("error","删除失败！","error");
            }
        }
    })
    
}

function modify(courseNo) {

    var course = getCourseInfoByNo(courseNo);

    //回填参数
    $("#info-courseNo-edit").textbox("setText",course.courseNo);
    $("#info-courseName-edit").textbox("setText",course.courseName);

    $("#info-dialog-edit").dialog('open');

    
}

function saveedit() {

    var param = {};

    param.courseNo = $("#info-courseNo-edit").textbox("getText");
    param.courseName = $("#info-courseName-edit").textbox("getText");

    url = baseUrl+"/course/modify";

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                course = result.data;
                $.messager.alert("success","修改成功！","info",function (){
                    window.location.href="";
                })
            }else{
                $.messager.alert("error","修改失败！","error");
            }
        }
    })

}