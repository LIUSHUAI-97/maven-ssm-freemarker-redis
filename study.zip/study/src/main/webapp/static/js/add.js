
/**
 * 关闭对应id的dialog框，比如传递的参数是查看对话框的id  （info-dialog）,则关闭查看信息对话框
 * @param dialogId
 */
function cancel(dialogId) {
    $("#" + dialogId).dialog('close');
}


/**
 * 通过Ajax请求，根据学号stuNo去获取学生信息
 * @param stuNo
 * @returns {*}
 */
function getStuInfoByStuNo(stuNo) {

    var stu;

    var url = baseUrl + "/stu/stuNo";
    var param = {};
    param.stuNo = stuNo + ""; // 将stuId转化为字符串，然后放到param中
    $.ajax({
        url: url,
        dataType: 'json',
        type: 'post',
        data: JSON.stringify(param),
        async: false,   // 取消异步执行，按照代码顺序同步执行
        contentType: 'application/json;charset=utf-8',
        success: function (result) {
            if (result.success) {
                stu = result.data;// 获取成功后将数据赋值给stu对象
            } else {
                // alert(result.msg);// 查询失败，则提示失败信息
                $.messager.alert('error', result.msg, 'error');
            }
        }
    })
    return stu;
}

function searchOne(stuNo) {
    console.log(stuNo);

    //根据学生学号去查询学生信息，然后回填到对话框中,
    // 方法一：根据之前查出来的放在freemarker中的stuList,去比对stuNo,从数组中取到stu对象，然后进行信息回填，
    // 优点是不用Ajax访问后台再去查一遍，但是写起来也比较麻烦，不通用
    // 方法二： Ajax去查询后台，然后回填，通用
    // 此处用方法二，Ajax

    // 调用getStuInfoByStuNo（stuNo）方法,从后台获取stu对象信息，然后用stu接收
    var stu = getStuInfoByStuNo(stuNo);

    // 将stu的信息回填到input中
    $("#info-stuNo").textbox('setText', stu.stuNo);
    $("#info-stuName").textbox('setText', stu.stuName);
    $("#info-addr").textbox('setText', stu.stuAddress);
    $("#info-birth").datebox('setValue', new Date(stu.birth).format('MM/dd/yyyy'));

    // 回填完成后打开对话框
    $("#info-dialog").dialog('open');
}

function deleteOne(stuNo) {
    // var stuNo = $("#info-stuNo").val();

    var param = {};
    param.stuNo = stuNo;
    console.log(param);

    url = baseUrl + "/stu/del";

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                // window.location.href="";
                window.location.reload();
            }else{
                $.messager.alert("error","没有"+stuNo,"error");
            }
        }
    })
}

function addOne() {

    var stuNo = $("#info-stuNo-add").val();
    var stuName = $("#info-stuName-add").val();
    var stuAddress = $("#info-addr-add").val();
    var birth = $("#info-birth-add").val();

    var param = {};
    param.stuNo = stuNo+"";
    param.stuName = stuName;
    param.stuAddress = stuAddress;
    param.birth = birth;

    url = baseUrl+"/stu/add";

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                param = result.data;
                $.messager.alert("添加成功","添加成功！","info")
                // cancel("info-dialog-add");
                window.location.reload();

            }else{
                $.messager.alert("error",result.msg,"error");
                // window.location.reload();
            }
        }
    })
    $("#info-dialog-add").dialog('open');
}

function modify(stuNo) {

    // searchOne(stuNo);

    var stu = getStuInfoByStuNo(stuNo);

    // 参数回填
    $("#info-stuNo-edit").textbox("setText",stu.stuNo);
    $("#info-stuName-edit").textbox("setText",stu.stuName);
    $("#info-addr-edit").textbox("setText",stu.stuAddress);
    $("#info-birth-edit").datebox("setValue",new Date(stu.birth).format("MM/dd/yyyy"));

    $("#info-dialog-edit").dialog("open");

}
function savemodify() {

    url = baseUrl+"/stu/modify";

    var param = {};
    //参数读取的是input 输入框中的值
    param.stuNo = $("#info-stuNo-edit").textbox("getText");
    param.stuName = $("#info-stuName-edit").textbox("getText");
    param.stuAddress = $("#info-addr-edit").textbox("getText");
    param.birth = $("#info-birth-edit").datebox("getValue");
    console.log(param);

    $.ajax({
        url:url,
        type:'post',
        data:JSON.stringify(param),
        dataType:'json',
        contentType:'application/json;charset=utf-8',
        success:function (result) {
            if(result.success){
                stu = result.data;
                window.location.reload();
            }else{
                $.messager.alert("error","修改失败","error");
            }
        }
    })
}

