package controller;

import entity.CourseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import service.CourseService;

import java.util.HashMap;
import java.util.Map;
//import service.CourseService;

@RestController
@RequestMapping("/course")
public class CourseController {

    @Autowired
    CourseService courseService;

    @RequestMapping(value="/selectOne",method = RequestMethod.POST)
    public Map<String,Object> selectOne(@RequestBody Map<String,Object> param){

        Map<String,Object> resMap = new HashMap<>();

        int courseNo = Integer.valueOf((String)(param.get("courseNo")));

        CourseEntity courseEntity = courseService.searchOne(courseNo);

        if(courseEntity!=null){
            resMap.put("success",true);
            resMap.put("data",courseEntity);
        }else{
            resMap.put("success",false);
            resMap.put("msg","没有该课程");
        }
        return resMap;
    }

    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public Map<String,Object> addOne(@RequestBody Map<String,Object> param){

        Map<String,Object> resMap = new HashMap<>();
        boolean success = false;
        try{
            int courseNo = Integer.valueOf((String)param.get("courseNo"));
            String courseName = (String)param.get("courseName");

            CourseEntity courseEntity = new CourseEntity();
            courseEntity.setCourseNo(courseNo);
            courseEntity.setCourseName(courseName);

            success = courseService.addOne(courseEntity);
        }catch (Exception e){
            resMap.put("success",false);
        }

        if(success){
            resMap.put("success",true);
        }else{
            resMap.put("success",false);
        }
        return resMap;
    }

    @RequestMapping(value = "/del",method = RequestMethod.POST)
    public Map<String,Object> deleteOne(@RequestBody Map<String,Object> param){

        Map<String,Object> resMap = new HashMap<>();

        int courseNo = Integer.valueOf((String)param.get("courseNo"));
//        String courseName = (String)param.get("courseName");

        boolean success = courseService.deleteOne(courseNo);

        if(success){
            resMap.put("success",true);
        }else{
            resMap.put("success",false);
        }
        return resMap;
    }

    @RequestMapping(value = "/modify",method = RequestMethod.POST)
    public Map<String,Object> modify(@RequestBody Map<String,Object> param){

        Map<String,Object> resMap = new HashMap<>();

        int courseNo = Integer.valueOf((String)param.get("courseNo"));
        String courseName = (String)param.get("courseName");

        CourseEntity courseEntity = courseService.searchOne(courseNo);

        courseEntity.setCourseNo(courseNo);
        courseEntity.setCourseName(courseName);

        boolean success = courseService.modify(courseEntity);
        if(success){
            resMap.put("success",true);
            resMap.put("data",courseEntity);
        }else{
            resMap.put("success",false);
        }
        return resMap;
    }
}
