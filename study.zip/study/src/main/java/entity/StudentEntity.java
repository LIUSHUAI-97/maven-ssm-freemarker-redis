package entity;

import java.io.Serializable;
import java.util.Date;

/**
 *使用redis 实体类必须实现Serializable接口  （序列化）
 *
 */
public class StudentEntity implements Serializable {

    private int stuId;

    private int stuNo;

    private String stuName;

    private String stuAddress;

    private Date birth;

    public int getStuId() {
        return stuId;
    }

    public void setStuId(int stuId) {
        this.stuId = stuId;
    }

    public int getStuNo() {
        return stuNo;
    }

    public void setStuNo(int stuNo) {
        this.stuNo = stuNo;
    }

    public String getStuName() {
        return stuName;
    }

    public void setStuName(String stuName) {
        this.stuName = stuName;
    }

    public String getStuAddress() {
        return stuAddress;
    }

    public void setStuAddress(String stuAddress) {
        this.stuAddress = stuAddress;
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public StudentEntity() {
    }

    public StudentEntity(int stuId, int stuNo, String stuName, String stuAddress, Date birth) {
        this.stuId = stuId;
        this.stuNo = stuNo;
        this.stuName = stuName;
        this.stuAddress = stuAddress;
        this.birth = birth;
    }
}
