package controller;

import dao.CourseMapper;
import dao.StudentMapper;
import entity.CourseEntity;
import entity.StudentEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import service.impl.CourseServiceImpl;
import service.impl.StudentServiceImpl;
import util.RedisUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    StudentMapper studentMapper;

    @Autowired
    CourseMapper courseMapper;

    // 注入redisTemplate  (缓存模板)
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    @RequestMapping("/")
    public ModelAndView index() {
        ModelAndView mv = new ModelAndView("stu_Index");

        /**
         * 0.判断redis是否存活，不存活，则直接读数据库，存活，则操作redis
         * 1.首先从redis中读取数据
         * 如果redis中读取的不为null或者空，则直接返回list
         * 如果redis中读取的为null或者空，则从数据库中查询，然后将查询出的结果添加到redis中
         * 最后返回list
         */

        List<StudentEntity> studentList = new ArrayList<>();

        if (RedisUtils.getRedisServiceIsAlive()) {   // redis 存活
            // 从redis中获取所有Student数据（返回的是collection对象）
            // StudentServiceImpl.STUDENT_MAP_KEY: 存储再redis中的map对象的键，
            // 结构类似这样： Map<StudentServiceImpl.STUDENT_MAP_KEY,Map<"学号01","张三对象">>
//            Map<StudentServiceImpl.STUDENT_MAP_KEY,Map<"学号02","李四对象">>
            // 操作redismap
            Collection<Object> stuCollection = redisTemplate.opsForHash().entries(StudentServiceImpl.STUDENT_MAP_KEY).values();
//            Collection<Object> courseCollection = redisTemplate.opsForHash().entries(CourseServiceImpl.COURSE_MAP_KEY).values();
            // 将集合对象转化成list
            studentList = RedisUtils.getCollectionObjectList(stuCollection, StudentEntity.class);

            if (null == studentList || studentList.isEmpty()) {  // redis中没有数据
                studentList = studentMapper.findAll();      // 从数据库中查询数据
                for (StudentEntity stu : studentList) {
                    redisTemplate.opsForHash().put(StudentServiceImpl.STUDENT_MAP_KEY, stu.getStuNo(), stu); //将数据存放进redis
                }
            }
        } else { //redis死了
            studentList = studentMapper.findAll();      // 从数据库中查询数据
        }


        mv.addObject("studentList", studentList);
        return mv;
    }

    @RequestMapping("/course")
    public ModelAndView course() {
        ModelAndView mv = new ModelAndView("course");
        List<CourseEntity> courseList = courseMapper.findAll();
        mv.addObject("courseList", courseList);
        return mv;
    }
}
